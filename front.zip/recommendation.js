window.addEventListener('DOMContentLoaded', getUserProfile);

function getUserProfile() {
  fetch('http://localhost:3001/userProfile')
    .then(response => response.json())
    .then(data => displayUserProfile(data))
    .catch(error => console.error('Error:', error));
}

function displayUserProfile(profile) {
  // Update the DOM elements with the received profile data
  const fullNameElement = document.querySelector('.profile-card p:nth-child(2)');
  const phoneNumberElement = document.querySelector('.profile-card p:nth-child(3)');
  const emailAddressElement = document.querySelector('.profile-card p:nth-child(4)');
  const passwordElement = document.querySelector('.profile-card p:nth-child(5)');
  const userNameElement = document.querySelector('.profile-card p:nth-child(6)');

  fullNameElement.textContent = `Full Name: ${profile.fullName}`;
  phoneNumberElement.textContent = `Phone Number: ${profile.phoneNumber}`;
  emailAddressElement.textContent = `Email Address: ${profile.emailAddress}`;
  passwordElement.textContent = `Password: ${profile.password}`;
  userNameElement.textContent = `User Name: ${profile.userName}`;
}
