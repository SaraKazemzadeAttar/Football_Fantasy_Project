// profile.js
document.addEventListener('DOMContentLoaded', () => {
  // Show the user profile after successful login
  getUserProfile();

  const deletePhotoButton = document.getElementById('delete-photo-button');
  const submitButton = document.getElementById('submit-button');

  deletePhotoButton.addEventListener('click', () => {
      const profilePhoto = document.querySelector('.profile-image');
      profilePhoto.src = '';
  });

  submitButton.addEventListener('click', () => {
      const fileInput = document.getElementById('profile-photo-input');
      const file = fileInput.files[0];

      const formData = new FormData();
      formData.append('profile-photo', file);

      // Add code here to handle the form data (e.g., submit it to the server)
  });

  const profilePhotoInput = document.getElementById('profile-photo-input');
  profilePhotoInput.addEventListener('change', () => {
      const file = profilePhotoInput.files[0];
      const reader = new FileReader();

      reader.onload = function (e) {
          const profilePhoto = document.querySelector('.profile-image');
          profilePhoto.src = e.target.result;
      }

      reader.readAsDataURL(file);
  });
});

function getCookie(name) {
    const cookies = document.cookie.split(';');
    for (let i = 0; i < cookies.length; i++) {
      const cookie = cookies[i].trim();
      if (cookie.startsWith(name + '=')) {
        return cookie.substring(name.length + 1);
      }
    }
    return null; // Cookie not found
  }

async function getUserProfile() {
  try {

    // Assuming you have a cookie named "jwt" that contains the JWT token.
        const jwtToken = getCookie('jwt');
        console.log(jwtToken);
      const response = await fetch('http://localhost:7005/userProfile', {
          method: 'GET', // Use the appropriate HTTP method for your API
          headers: {
              'Content-Type': 'application/json',
              'Authorization':  jwtToken
              
          },
         
      });

      if (!response.ok) {
          throw new Error('Network response was not ok.');
      }

      const userProfile = await response.json();

      // Update the HTML elements with the user profile data
      document.getElementById('fullName').textContent = userProfile.fullName;
      document.getElementById('email').textContent = userProfile.email;
      document.getElementById('mobilePhone').textContent = userProfile.mobilePhone;
      document.getElementById('userName').textContent = userProfile.userName;
  } catch (error) {
      console.error('Error fetching user profile:', error);
  }
}
