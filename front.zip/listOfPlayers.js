document.addEventListener("DOMContentLoaded", function () {
  fetch('http://localhost:7005/ShowListOfPlayers')
    .then((response) => response.json())
    .then((data) => {
      const tableBody = document.getElementById("sortable-body");
      tableBody.innerHTML = ""; // Clear existing data from the table

      data.forEach((player) => {
        const row = document.createElement("tr");

        const nameCell = createTableCell(player.first_name + " " + player.second_name);
        const positionCell = createTableCell(player.element_type);
        const teamCell = createTableCell(player.team);
        const scoreCell = createTableCell(player.total_points);
        const priceCell = createTableCell(player.now_cost);

        row.appendChild(nameCell);
        row.appendChild(positionCell);
        row.appendChild(teamCell);
        row.appendChild(scoreCell);
        row.appendChild(priceCell);

        tableBody.appendChild(row);
      });
    })
    .catch((error) => {
      console.error("Error fetching player data:", error);
    });
});

function createTableCell(content) {
  const cell = document.createElement("td");
  cell.textContent = content;
  return cell;
}

function updateTableWithFilteredData(filteredData) {
  const tableBody = document.getElementById("sortable-body");
  tableBody.innerHTML = ""; // Clear existing data from the table

  filteredData.forEach((player) => {
    const row = document.createElement("tr");

    const nameCell = createTableCell(player.first_name + " " + player.second_name);
    const positionCell = createTableCell(player.element_type);
    const teamCell = createTableCell(player.team);
    const scoreCell = createTableCell(player.total_points);
    const priceCell = createTableCell(player.now_cost);

    row.appendChild(nameCell);
    row.appendChild(positionCell);
    row.appendChild(teamCell);
    row.appendChild(scoreCell);
    row.appendChild(priceCell);

    tableBody.appendChild(row);
  });
}

function getSelectedValue() {
  
  let selectedValue = document.getElementById("filter-select").value;
}

function getSortValue() {
  
  let sortValue = document.getElementById("sort-select").value;
  console.log(sortValue);

}


document.getElementById("search-form").addEventListener("submit", function (event) {
  event.preventDefault(); 
  console.log(event);
  filter(); 
});

   function filter() {
   var selectedValue = document.getElementById("filter-select").value;
   var sortValue = document.getElementById("sort-select").value;
   console.log(selectedValue);

   if (selectedValue === "name") {
     let entry = document.getElementById("filter-input").value;
     console.log(entry);

     let url = "http://localhost:7005/filterPlayersByName?" + new URLSearchParams({
       entry: entry,
    });
    console.log(url);
    fetch(url, {
      method: "GET",
      mode: "cors",
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json' 
      },
    })
      .then(response => response.json()) 
      .then(data => {
        console.log(data);
        updateTableWithFilteredData(data);
      })
      .catch((error) => {
        console.error("Error:", error.message);
        alert("An error occurred. Please try again later: " + error.message);
      });
    }

    if (selectedValue === "position") {
      let post = document.getElementById("post-input").value;
      console.log(post);
 
      let url = "http://localhost:7005/filterPlayersByPost?" + new URLSearchParams({
        post: post,
     });
     fetch(url, {
       method: "GET",
       mode: "cors",
       headers: {
         'Accept': 'application/json',
         'Content-Type': 'application/json' 
       },
     })
       .then(response => response.json()) 
       .then(data => {
         console.log(data);
         updateTableWithFilteredData(data);
       })
       .catch((error) => {
         console.error("Error:", error.message);
         alert("An error occurred. Please try again later: " + error.message);
       });
     }

     if (selectedValue === "price" && sortValue==="ascending" ) {
      let url = "http://localhost:7005/filterPlayersByAscendingPrice"
     console.log(url);
     fetch(url, {
       method: "GET",
       mode: "cors",
       headers: {
         'Accept': 'application/json',
         'Content-Type': 'application/json' 
       },
     })
       .then(response => response.json()) 
       .then(data => {
         console.log("kkkkkkk",data);
         updateTableWithFilteredData(data);
       })
       .catch((error) => {
         console.error("Error:", error.message);
         alert("An error occurred. Please try again later: " + error.message);
       });
     }

     if (selectedValue === "price" && sortValue==="descending" ) {
      let url = "http://localhost:7005/filterPlayersByDescendingPrice"
     console.log(url);
     fetch(url, {
       method: "GET",
       mode: "cors",
       headers: {
         'Accept': 'application/json',
         'Content-Type': 'application/json' 
       },
     })
       .then(response => response.json()) 
       .then(data => {
         updateTableWithFilteredData(data);
       })
       .catch((error) => {
         console.error("Error:", error.message);
         alert("An error occurred. Please try again later: " + error.message);
       });
     }

     if (selectedValue === "score" && sortValue==="ascending" ) {
      let url = "http://localhost:7005/filterPlayersByDescendingPoint"
     console.log(url);
     fetch(url, {
       method: "GET",
       mode: "cors",
       headers: {
         'Accept': 'application/json',
         'Content-Type': 'application/json' 
       },
     })
       .then(response => response.json()) 
       .then(data => {
         updateTableWithFilteredData(data);
       })
       .catch((error) => {
         console.error("Error:", error.message);
         alert("An error occurred. Please try again later: " + error.message);
       });
     }

     
     if (selectedValue === "score" && sortValue==="descending" ) {
      let url = "http://localhost:7005/filterPlayersByAscendingPoint"
     console.log(url);
     fetch(url, {
       method: "GET",
       mode: "cors",
       headers: {
         'Accept': 'application/json',
         'Content-Type': 'application/json' 
       },
     })
       .then(response => response.json()) 
       .then(data => {
         updateTableWithFilteredData(data);
       })
       .catch((error) => {
         console.error("Error:", error.message);
         alert("An error occurred. Please try again later: " + error.message);
       });
     }
 }



 