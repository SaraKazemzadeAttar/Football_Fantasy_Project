document.addEventListener('DOMContentLoaded', () => {
  showInfo();
})

function getCookie(name) {
  const cookies = document.cookie.split(';');
  for (let i = 0; i < cookies.length; i++) {
    const cookie = cookies[i].trim();
    if (cookie.startsWith(name + '=')) {
      return cookie.substring(name.length + 1);
    }
  }
  return null; // Cookie not found
}

async function showInfo(){
  const jwtToken = getCookie('jwt');
      //console.log(jwtToken);
    const response = await fetch('http://localhost:7005/userProfile', {
        method: 'GET', // Use the appropriate HTTP method for your API
        headers: {
            'Content-Type': 'application/json',
            'Authorization':  jwtToken
            
        },  
    });
    const userProfile = await response.json();
    //console.log(userProfile);
    

        const tableBody = document.getElementById("sortable-body");
    //console.log(tableBody);

        tableBody.innerHTML = ""; // Clear existing data from the table
  
        
          const row = document.createElement("tr");
  
          const nameCell = createTableCell(userProfile.first_name + " " + userProfile.second_name);
    console.log(nameCell);

          const positionCell = createTableCell(userProfile.element_type);
          const teamCell = createTableCell(userProfile.team);
          const scoreCell = createTableCell(userProfile.total_points);
          const priceCell = createTableCell(userProfile.now_cost);
  
          row.appendChild(nameCell);
          row.appendChild(positionCell);
          row.appendChild(teamCell);
          row.appendChild(scoreCell);
          row.appendChild(priceCell);
  
          tableBody.appendChild(row);
        
      
      
       console.log(response);
}