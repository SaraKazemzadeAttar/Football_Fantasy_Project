const userTable = document.getElementById("userTable");

fetch('http://localhost:7005/showScoresTable')
  .then(response => response.json())
  .then(data => {
    const scoreTableData = data;

    scoreTableData.forEach((rowData, index) => {
      const newRow = document.createElement("tr");
      const newNo = document.createElement("td");
      const newfullName = document.createElement("td");
      const newScore = document.createElement("td");

      newNo.textContent = index + 1;
      newfullName.textContent = rowData.fullName;
      newScore.textContent = rowData.score;

      newRow.appendChild(newNo);
      newRow.appendChild(newfullName);
      newRow.appendChild(newScore);

      userTable.appendChild(newRow);
    });
  })
  //.catch(error => console.error(error));
