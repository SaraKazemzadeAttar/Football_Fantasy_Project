let form = document.getElementById("signup-form");
form.addEventListener("submit", signup);

function signup(event) {
  alert("done")
  event.preventDefault();

  let password = document.getElementById("password").value;
  let mobilePhone = document.getElementById("mobilePhone").value;
  let email = document.getElementById("email").value;
  let fullName = document.getElementById("fullName").value;
  let userName = document.getElementById("userName").value;


  alert([password, mobilePhone, email, fullName,userName]); //for test
  let data = { fullName: fullName, email: email, password: password, mobilePhone: mobilePhone ,userName:userName};//rast mesie back
  console.log(data);
  console.log(JSON.stringify(data));
  let url = "http://localhost:7005/signUp";
  fetch(url, {
    method: "POST",
    mode: "cors",
   headers: {
    'Accept': 'application/json',
    'Content-Type': 'application/json' // Set the Content-Type header to JSON
  },
    body: JSON.stringify(data),
  })
  .then((response) => {
    console.log(response);
    if (!response.ok) {
      // Check if the response status is an error (e.g., 400 Bad Request)
      return response.json().then(data => {
        console.log(data);
        throw new Error(data.message || "An error occurred.");
      });
    }
    else
     { 
      window.location.href = "otp.html"; // Replace "other_page.html" with the actual page URL
     return response.text();
    }
  })  
 .catch((error) => {
    console.error("Error:", error.message);
    alert("An error occurred. Please try again later : " + error.message);
  });
}

//login//
let formLogin = document.getElementById("login");
formLogin.addEventListener("submit", login);

function login(event) {
  event.preventDefault();

  let password = document.getElementById("password1").value;
  let email_username = document.getElementById("email_username").value;

  //console.log(data);
  //console.log(JSON.stringify(data));
  let url ="http://localhost:7005/login?"+new URLSearchParams({
    password:password,
    email_username:email_username,
})
  fetch(url, {
    method: "POST",
    mode: "cors",
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json' // Set the Content-Type header to JSON
    },
  })
  .then(response=>response.json())
  .then(data=>{ console.log(data); 
    const jwtToken =data.token;
    document.cookie = `jwt=${jwtToken}; SameSite=None; Secure; expires=Fri, 31 Dec 9999 23:59:59 GMT; path=/`;
      console.log(jwtToken);
      window.location.href = "mainpage.html"; // Replace "other_page.html" with the actual page URL
    })
 .catch((error) => {
    console.error("Error:", error.message);
    alert("An error occurred. Please try again later : " + error.message);
  });

}



