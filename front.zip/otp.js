const digit1 = document.getElementById('digit1');
const digit2 = document.getElementById('digit2');
const digit3 = document.getElementById('digit3');
const digit4 = document.getElementById('digit4');
const emailInput = document.getElementById('email');
const verifyButton = document.querySelector('button');

// Disable the "Verify" button by default
verifyButton.disabled = true;

// Add an event listener to each input field
digit1.addEventListener('input', enableButton);
digit2.addEventListener('input', enableButton);
digit3.addEventListener('input', enableButton);
digit4.addEventListener('input', enableButton);
emailInput.addEventListener('input', enableButton);

function enableButton() {
  // Enable the "Verify" button only if all inputs have a value
  if (digit1.value && digit2.value && digit3.value && digit4.value && emailInput.value) {
    verifyButton.disabled = false;
  } else {
    verifyButton.disabled = true;
  }
}

verifyButton.addEventListener('click', () => {
  const otp = `${digit1.value}${digit2.value}${digit3.value}${digit4.value}`;
  const email = emailInput.value;
  
  fetch('http://localhost:7005/otp', {
    method: 'POST',
    headers: {
      'Accept': 'application/json',
    mode: "cors",
      'Content-Type': 'application/json' // Set the Content-Type header to JSON
    },
    body: JSON.stringify({ OTPCode: otp, email: email })
  })
  .then(response => {
    if (response.ok) {
      response.json().then(data => {
        alert(data.message );
      });
      window.location.href = '1.html';// Redirect to the login page
    } else {
       response.json().then(data => {
        alert(data.message );
      });
      
    }
  })
  .catch((error) => {
    console.error("Error:", error.message);
    alert("An error occurred. Please try again later : " + error.message);
  });
});


// Wait for the DOM to load
document.addEventListener("DOMContentLoaded", function() {
  // Get all the input elements
  var inputs = document.querySelectorAll(".otp_card_inputs input");

  // Add event listener to each input
  inputs.forEach(function(input, index) {
    input.addEventListener("input", function() {
      // Move to the next input field if the current input is not empty
      if (this.value !== "" && index < inputs.length - 1) {
        inputs[index + 1].focus();
      }
    });
  });
});
